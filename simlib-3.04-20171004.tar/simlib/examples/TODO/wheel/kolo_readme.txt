
WHEEL2.CPP
----------


zmenit strukturu na:  3 objekty zapouzdrene do systemu


         f            f                f
ground ------ wheel ---- spring+dump ----- car body

gravity


upravit!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
