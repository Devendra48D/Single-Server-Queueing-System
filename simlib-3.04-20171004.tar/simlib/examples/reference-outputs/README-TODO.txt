
Reference results for SIMLIB/C++ examples
=========================================

You should get the same results in 32bit environment.

64bit version uses SSE instructions with slightly less accuracy of comutation
- some tiny rounding differences are expected.

TODO: use fenv to set rounding etc.
      use english names and comments
      try to print resuts with less accuracy to mask rounding errors


